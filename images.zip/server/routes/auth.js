const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../database');
const router = express.Router();

// Register user
router.post('/register', async (req, res) => {
    const { email, password, type, ...profileData } = req.body;

    if (!email || !password || !type) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const password_hash = await bcrypt.hash(password, 10);

        const stmt = db.prepare(`
            INSERT INTO users (email, password_hash, type, business_name, contact_name, phone, ein, certification_number, organization_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        const result = stmt.run(
            email,
            password_hash,
            type,
            profileData.businessName || null,
            profileData.contactName || null,
            profileData.phone || null,
            profileData.ein || null,
            profileData.certificationNumber || null,
            profileData.organizationName || null
        );

        const newUser = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
        const { password_hash: _, ...userWithoutPassword } = newUser;
        res.status(201).json(userWithoutPassword);
    } catch (error) {
        if (error.message.includes('UNIQUE constraint failed')) {
            return res.status(400).json({ error: 'Email already exists' });
        }
        res.status(500).json({ error: error.message });
    }
});

// Login user
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        return res.status(401).json({ error: 'Invalid email or password' });
    }

    const { password_hash, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
});

// Update user profile
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const profileData = req.body;

    try {
        const stmt = db.prepare(`
            UPDATE users SET 
                business_name = COALESCE(?, business_name),
                contact_name = COALESCE(?, contact_name),
                phone = COALESCE(?, phone),
                ein = COALESCE(?, ein),
                certification_number = COALESCE(?, certification_number),
                organization_name = COALESCE(?, organization_name),
                districts = COALESCE(?, districts),
                categories = COALESCE(?, categories)
            WHERE id = ?
        `);

        stmt.run(
            profileData.businessName || null,
            profileData.contactName || null,
            profileData.phone || null,
            profileData.ein || null,
            profileData.certificationNumber || null,
            profileData.organizationName || null,
            profileData.districts ? JSON.stringify(profileData.districts) : null,
            profileData.categories ? JSON.stringify(profileData.categories) : null,
            id
        );

        const updatedUser = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
        const { password_hash, ...userWithoutPassword } = updatedUser;
        res.json(userWithoutPassword);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
