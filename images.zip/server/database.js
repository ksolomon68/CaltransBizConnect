const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.resolve(__dirname, '../data.db');
const db = new Database(dbPath, { verbose: console.log });

// Initialize database schema
function initDatabase() {
    // Users table
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            type TEXT NOT NULL,
            business_name TEXT,
            contact_name TEXT,
            phone TEXT,
            ein TEXT,
            certification_number TEXT,
            organization_name TEXT,
            districts TEXT,
            categories TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Opportunities table
    db.exec(`
        CREATE TABLE IF NOT EXISTS opportunities (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            scope_summary TEXT NOT NULL,
            district TEXT NOT NULL,
            district_name TEXT NOT NULL,
            category TEXT NOT NULL,
            category_name TEXT NOT NULL,
            subcategory TEXT,
            estimated_value TEXT,
            due_date TEXT,
            due_time TEXT,
            submission_method TEXT,
            posted_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            posted_by INTEGER,
            FOREIGN KEY (posted_by) REFERENCES users (id)
        )
    `);

    console.log('Database initialized successfully.');

    // Seed data for initial deployment
    const count = db.prepare('SELECT COUNT(*) as count FROM opportunities').get().count;
    if (count === 0) {
        console.log('Seeding initial opportunities...');
        const seedStmt = db.prepare(`
            INSERT INTO opportunities (
                id, title, scope_summary, district, district_name, 
                category, category_name, subcategory, estimated_value, 
                due_date, due_time, submission_method
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        const seeds = [
            [
                'opp-001',
                'District 4 Bridge Maintenance Support',
                'Provide specialized technical assistance for ongoing bridge maintenance projects in the Bay Area.',
                '04', 'D04 - Bay Area / Oakland',
                'services', 'Support Services',
                'Technical Assistance', '$150,000 - $300,000',
                '2026-03-15', '14:00', 'Electronic Submission'
            ],
            [
                'opp-002',
                'Statewide DBE Supportive Services Program',
                'Comprehensive supportive services including training workshops and technical assistance for certified DBEs.',
                '74', 'D74 - Headquarters',
                'services', 'Support Services',
                'Training', '$500,000+',
                '2026-04-01', '10:00', 'Caltrans Portal'
            ],
            [
                'opp-003',
                'District 7 Guardrail Repair Contract',
                'Emergency and scheduled guardrail repair services across various locations in Los Angeles county.',
                '07', 'D07 - Los Angeles',
                'construction', 'Construction',
                'Specialty Contracting', '$2,000,000',
                '2026-02-28', '16:00', 'Hard Copy / In-Person'
            ]
        ];

        for (const seed of seeds) {
            seedStmt.run(...seed);
        }
        console.log('Seeded 3 sample opportunities.');
    }

    // Seed test accounts if they don't exist
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    if (userCount === 0) {
        console.log('Seeding initial test accounts...');
        const bcrypt = require('bcryptjs');
        const hash = bcrypt.hashSync('Password123!', 10);

        const userStmt = db.prepare(`
            INSERT INTO users (email, password_hash, type, business_name, organization_name)
            VALUES (?, ?, ?, ?, ?)
        `);

        userStmt.run('vendor@test.com', hash, 'vendor', 'Test Vendor Co', null);
        userStmt.run('agency@test.com', hash, 'agency', null, 'Test Agency Dept');
        console.log('Seeded 2 test accounts (vendor@test.com, agency@test.com)');
    }
}

module.exports = {
    db,
    initDatabase
};
