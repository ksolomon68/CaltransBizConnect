const express = require('express');
const { db } = require('../database');
const router = express.Router();

// Get all opportunities
router.get('/', (req, res) => {
    try {
        const opportunities = db.prepare('SELECT * FROM opportunities ORDER BY posted_date DESC').all();
        res.json(opportunities);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Post new opportunity
router.post('/', (req, res) => {
    const {
        id, title, scopeSummary, district, districtName,
        category, categoryName, subcategory, estimatedValue,
        dueDate, dueTime, submissionMethod, postedBy
    } = req.body;

    if (!id || !title || !scopeSummary) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
        const stmt = db.prepare(`
            INSERT INTO opportunities (
                id, title, scope_summary, district, district_name, 
                category, category_name, subcategory, estimated_value, 
                due_date, due_time, submission_method, posted_by
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run(
            id, title, scopeSummary, district, districtName,
            category, categoryName, subcategory || null, estimatedValue || null,
            dueDate || null, dueTime || null, submissionMethod || null, postedBy || null
        );

        res.status(201).json({ id, title, status: 'published' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
