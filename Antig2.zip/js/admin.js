/**
 * Admin Logic Module
 * Handles administrative data management (simulated for demo)
 */

const ADMIN_DATA_KEY = 'caltrans_admin_data';

// Initialize admin data if not exists
function initAdminData() {
    if (!localStorage.getItem(ADMIN_DATA_KEY)) {
        const initialData = {
            stats: {
                totalVendors: 142,
                totalAgencies: 28,
                pendingApprovals: 8,
                siteUptime: '99.9%'
            },
            recentActivity: [
                { type: 'user_reg', user: 'BuildIt Corp', time: '2 hours ago' },
                { type: 'opp_post', user: 'District 4', time: '4 hours ago' },
                { type: 'user_reg', user: 'EcoConsultants', time: '1 day ago' }
            ],
            pendingOpportunities: [
                { id: 'opp-101', title: 'Highway Repair J-44', agency: 'CALTRANS District 7', date: '2026-02-01' },
                { id: 'opp-102', title: 'IT Consulting Services', agency: 'Department of General Services', date: '2026-02-03' }
            ]
        };
        localStorage.setItem(ADMIN_DATA_KEY, JSON.stringify(initialData));
    }
}

function getAdminData() {
    initAdminData();
    return JSON.parse(localStorage.getItem(ADMIN_DATA_KEY));
}

function approveOpportunity(id) {
    const data = getAdminData();
    data.pendingOpportunities = data.pendingOpportunities.filter(opp => opp.id !== id);
    data.stats.pendingApprovals = data.pendingOpportunities.length;
    localStorage.setItem(ADMIN_DATA_KEY, JSON.stringify(data));
    return true;
}

// Global initialization
document.addEventListener('DOMContentLoaded', initAdminData);
