/**
 * CaltransBizConnect Configuration
 * Automatically detects environment to set correct API endpoints
 */

const CONFIG = {
    // Detect environment
    isLocal: window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1',

    // Set base API URL
    get API_URL() {
        if (this.isLocal) {
            return 'http://localhost:3000/api';
        } else {
            // production / shared server
            // On cPanel/Passenger, the API might be at /api relative to the domain
            return window.location.origin + '/api';
        }
    }
};

window.APP_CONFIG = CONFIG;
console.log('CaltransBizConnect: Config loaded for environment:', CONFIG.isLocal ? 'DEVELOPMENT' : 'PRODUCTION');
